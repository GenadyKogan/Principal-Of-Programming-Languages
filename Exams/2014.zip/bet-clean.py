# Q1: RECURSION & RECURSIVE DS (20 points)

def map_tree_reverse(t, f):
    if type(t) != tuple:
        return f(t)
    return tuple(map_tree_reverse(i, f) for i in t[::-1])

    
#print(map_tree_reverse(((2,3), (1,2,3)), lambda x: x*2))
#print(map_tree_reverse(((2,3,(5,6)), (1,2,3)), lambda x: x*2))
print(map_tree_reverse(((1,(2,3)),5,((6,7),(8,9))), lambda x: x*2))

# Q5: INTERPRETER (15-20 points)

from functools import reduce
from operator import mul,add
from math import sqrt

def repl():
    
    while True:
        try:
            expression_tree = calc_parse(input('calc> '))
            print(calc_eval(expression_tree))
        #### new errors: ValueError, ArithmeticError ####
        except (SyntaxError, TypeError, ZeroDivisionError, ValueError, ArithmeticError) as err:
            print(type(err).__name__ + ':', err)
        except (KeyboardInterrupt, EOFError):  # <Control>-D, etc. <ctrl-C>
            print('Calculation completed.')
            return

# Eval & Apply

class Exp(object):
    def __init__(self, operator, operands):
        self.operator = operator
        self.operands = operands

    def __repr__(self):
        return 'Exp({0}, {1})'.format(repr(self.operator), repr(self.operands))

    def __str__(self):
        operand_strs = ', '.join(map(str, self.operands))
        return '{0}({1})'.format(self.operator, operand_strs)

def calc_eval(exp):
    if type(exp) in (int, float):
        return exp
    if type(exp) == Exp:
        arguments = list(map(calc_eval, exp.operands))
        return calc_apply(exp.operator, arguments)
    
def calc_apply(operator, args):
    if operator in ('add', '+'):
        return sum(args)
    if operator in ('sub', '-'):
        if len(args) == 0:
            raise TypeError(operator + 'requires at least 1 argument')
        if len(args) == 1:
            return -args[0]
        return sum(args[:1] + [-arg for arg in args[1:]])
    if operator in ('mul', '*'):
        return reduce(mul, args, 1)
    if operator in ('div', '/'):
        if len(args) != 2:
            raise TypeError(operator + ' requires exactly 2 arguments')
        numer, denom = args
        return float(numer)/denom
    #### new operator - pow ####
    if operator in ('pow', '^'):
        if len(args) != 2:
            raise TypeError(operator + ' requires exactly 2 arguments')
        base, num = args
        return pow(base, num)
    #############################
    #### new operator - sqrt ####
    if operator in ('sqrt', 'V'):
        if len(args) != 1:
            raise TypeError(operator + ' requires exactly 1 argument')
        return sqrt(args[0])
    #############################

# Parsing

def calc_parse(line):
    tokens = tokenize(line)
    expression_tree = analyze(tokens)
    if len(tokens) > 0:
        raise SyntaxError('Extra token(s): ' + ' '.join(tokens))
    return expression_tree

def tokenize(line):
    spaced = line.replace('(',' ( ').replace(')',' ) ').replace(',', ' , ')
    return spaced.strip().split()

#### new operators: 'pow', 'sqrt', '^', 'V'
known_operators = ['add', 'sub', 'mul', 'div', 'pow', 'sqrt', '+', '-', '*', '/', '^', 'V']

def analyze(tokens):
    assert_non_empty(tokens)
    token = analyze_token(tokens.pop(0))
    if type(token) in (int, float):
        return token
    if token in known_operators:
        if len(tokens) == 0 or tokens.pop(0) != '(':
            raise SyntaxError('expected ( after ' + token)
        return Exp(token, analyze_operands(tokens))
    else:
        return token
        
def analyze_operands(tokens):
    assert_non_empty(tokens)
    operands = []
    while tokens[0] != ')':
        if operands and tokens.pop(0) != ',':
            raise SyntaxError('expected ,')
        operands.append(analyze(tokens))
        assert_non_empty(tokens)
    tokens.pop(0)  # Remove )
    return operands

def assert_non_empty(tokens):
    if len(tokens) == 0:
        raise SyntaxError('unexpected end of line')

def analyze_token(token):
    try:
        return int(token)
    except (TypeError, ValueError):
        try:
            return float(token)
        except (TypeError, ValueError):
            return token

# Q2: PIPELINE, MESSAGE PASSING, DISPATCH FUNCTION (25 points)
# stopwords (low case) removal, bi-grams
stop_list = ('is', 'it', 'are', 'the', 'and', 'for')
#text = 'My 100 friends are very friendly They are keeping our friendship'
text = '100 bananas AND 50 apples are fruits for salad'

def text_processing(stopwords):
    def remove_stopwords(words):
        return filter(lambda x: x not in stopwords, words)
    def remove_numbers(words):
        return filter(lambda x: not x.isnumeric(), words)
    def get_words(text):
        return map(lambda x: x.lower(), text.split())
    def get_bigrams(terms):
        tterms = tuple(terms)
        return map(lambda x, y: (x,y), tterms, tterms[1:])
    def print_bigrams(g):
        for x,y in g:
            print('{0}-{1}'.format(x,y))
    def dispatch(msg):
        if msg == 'remove_stopwords':
            return remove_stopwords
        if msg == 'remove_numbers':
            return remove_numbers
        if msg == 'get_words':
            return get_words
        if msg == 'get_bigrams':
            return get_bigrams
        if msg == 'print_bigrams':
            return print_bigrams
        else:
            return 'Unknown message '+msg
    return dispatch

engine = text_processing(stop_list)
engine('print_bigrams')(engine('get_bigrams')(engine('remove_stopwords')(engine('remove_numbers')(engine('get_words')(text)))))
#print(tuple(engine['stemming'](engine['remove_stopwords'](engine['get_words'](text)))))
#print(tuple(engine['get_bigrams'](engine['remove_numbers'](engine['get_words'](text)))))

# Q4: GENERIC FUNCTIONS

class Triangle():
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c
    def perimeter(self):
        return self.a+self.b+self.c
    def __add__(self, other):
        return self.perimeter()+other.perimeter()

class Square():
    def __init__(self, a):
        self.a = a
    def perimeter(self):
        return self.a*4
    def __add__(self, other):
        return self.perimeter()+other.perimeter()

t = Triangle(1,2,3)
print(t.perimeter())
s = Square(2)
print(s.perimeter())
print(t+s)


