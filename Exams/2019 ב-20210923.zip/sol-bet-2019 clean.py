﻿from operator import add,sub
### ---bet Q1 ---###
def is_binary(tree):
    if type(tree) != tuple:
        return True
    if len(tree) != 2:
        return False
    return is_binary(tree[0]) and is_binary(tree[1])

# print(is_binary(((2, 3), (4, (5, 6)))))
# True
# print(is_binary((2, (3, (4, 5, 6)))))
# False

def filter_tree(f, tree):
    return tuple(el for el in tree if type(el)!=tuple and f(el)) + tuple(filter_tree(f, el) for el in tree if type(el)==tuple)

print(filter_tree(lambda x: x%2==0, (1, 2, (3,4,5),6,7)))
print(filter_tree(lambda x: x%2==0, (1, 2, (3,4,(8,9),5),6,7)))


### --- Q3 ---
from functools import reduce
wordnet = ('catapulta', 'caput', 'catephant')
w1,w2 = 'cat','elephant'
prefixes = lambda w: tuple(map(lambda i: w[:i], range(1,len(w)+1)))
print(prefixes(w1))
suffixes = lambda w: tuple(map(lambda i: w[i:], range(0,len(w))))
print(suffixes(w2))
concats = lambda a,lst: tuple(map(lambda x: x+a, lst))
print(concats('aa',('bb','cc','dd')))
all_concats = lambda lst1, lst2: tuple(map(lambda x: concats(x,lst1), lst2))
print(all_concats(('aa','bb'),('c','d','e')))
all_concats_flat = lambda lst1, lst2: reduce(add, all_concats(lst1,lst2))
print(all_concats_flat(('aa','bb'),('c','d','e')))
words_generator = lambda w1, w2: all_concats_flat(prefixes(w1),suffixes(w2))
print(words_generator(w1,w2))
words = lambda w1,w2: tuple(filter(lambda x: x in wordnet, words_generator(w1,w2)))
print(words(w1,w2))


### --- Q4 ---
# INTERPRETER (25 points)
##-------------Appendix--------------##
##def repl():
##    ### initialize GLOBAL environment ###
##    
##    ##############################
##    while True:
##        try:            
##            expr = calc_parse(input('calc>'))
##            print(calc_eval(expr))                   
##        except (SyntaxError, TypeError, ZeroDivisionError, NameError) as err:
##            print(type(err).__name__ + ':', err)
##        except (KeyboardInterrupt, EOFError):  # <Control>-D, etc. <ctrl-C>
##            print('Calculation completed.')
##            return
##
### Eval & Apply
##
##class Exp(object):
##    def __init__(self, operator, operands):
##        self.operator = operator
##        self.operands = operands
##
##    def __repr__(self):
##        return 'Exp({0}, {1})'.format(repr(self.operator), repr(self.operands))
##
##    def __str__(self):
##        operand_strs = ', '.join(map(str, self.operands))
##        return '{0}({1})'.format(self.operator, operand_strs)
##
##def calc_eval(exp):
##    if type(exp) in (int, float):
##        return exp
##    if type(exp) == Exp:
##        arguments = list(map(calc_eval, exp.operands))
##        return calc_apply(exp.operator, arguments)
##    ### if token is variable ###
##
##
##def calc_apply(operator, args):
##    if operator in ('add', '+'):
##        return sum(args)
##    if operator in ('sub', '-'):
##        if len(args) == 0:
##            raise TypeError(operator + 'requires at least 1 argument')
##        if len(args) == 1:
##            return -args[0]
##        return sum(args[:1] + [-arg for arg in args[1:]])
##    if operator in ('mul', '*'):
##        return reduce(mul, args, 1)
##    if operator in ('div', '/'):
##        if len(args) != 2:
##            raise TypeError(operator + ' requires exactly 2 arguments')
##        numer, denom = args
##        return float(numer)/denom
##
##def calc_parse(line):
##    tokens = tokenize(line)
##    ### distinguish between assignment and expression ###
##    
##    #####################################################
##        expression_tree = analyze(tokens)
##        if len(tokens) > 0:
##            raise SyntaxError('Extra token(s): ' + ' '.join(tokens))
##        return expression_tree
##
##### add token '=' ###
##def tokenize(line):
##    spaced = line.replace('(',' ( ').replace(')',' ) ').replace(',', ' , ')
##    return spaced.strip().split()
##
##known_operators = ['add', 'sub', 'mul', 'div', '+', '-', '*', '/']
##
######## execute assignment x = expression ######
##def execute(tokens):
##    
#################################################
##    
##def analyze(tokens):
##    assert_non_empty(tokens)
##    token = analyze_token(tokens.pop(0))
##    if type(token) in (int, float):
##        return token
##    if token in known_operators:
##        if len(tokens) == 0 or tokens.pop(0) != '(':
##            raise SyntaxError('expected ( after ' + token)
##        return Exp(token, analyze_operands(tokens))
##    else:
##        return token
##        
##def analyze_operands(tokens):
##    assert_non_empty(tokens)
##    operands = []
##    while tokens[0] != ')':
##        if operands and tokens.pop(0) != ',':
##            raise SyntaxError('expected ,')
##        operands.append(analyze(tokens))
##        assert_non_empty(tokens)
##    tokens.pop(0)  # Remove )
##    return operands
##
##def assert_non_empty(tokens):
##    if len(tokens) == 0:
##        raise SyntaxError('unexpected end of line')
##
##def analyze_token(token):
##    try:
##        return int(token)
##    except (TypeError, ValueError):
##        try:
##            return float(token)
##        except (TypeError, ValueError):
##            return token

##SOLUTION
from functools import reduce
from operator import mul,add

def repl():
    ### initialize GLOBAL environment ###
    global env
    env = {}
    ##############################
    while True:
        try:
            row = input('calc> ')
            expression_tree = calc_parse(row)
            ### avoid printing 'None' ###
            if expression_tree:
                #############################
                print(calc_eval(expression_tree))
        except (SyntaxError, TypeError, ZeroDivisionError, NameError) as err:
            print(type(err).__name__ + ':', err)
        except (KeyboardInterrupt, EOFError):  # <Control>-D, etc. <ctrl-C>
            print('Calculation completed.')
            return

# Eval & Apply

class Exp(object):
    def __init__(self, operator, operands):
        self.operator = operator
        self.operands = operands

    def __repr__(self):
        return 'Exp({0}, {1})'.format(repr(self.operator), repr(self.operands))

    def __str__(self):
        operand_strs = ', '.join(map(str, self.operands))
        return '{0}({1})'.format(self.operator, operand_strs)

def calc_eval(exp):
    if type(exp) in (int, float):
        return exp
    if type(exp) == Exp:
        arguments = list(map(calc_eval, exp.operands))
        return calc_apply(exp.operator, arguments)
    ### if token is variable ###
    elif type(exp) == str:
        if exp in env:
            return env[exp]
        else:
            raise NameError('unbound variable ' + exp)

##applicative order - all arguments are already evaluated
def calc_apply(operator, args):
    #alef#
    if len(args) == 0:
            raise TypeError('all operators require at least 1 argument')
    ######
    if operator in ('add', '+'):
        return sum(args)
    if operator in ('sub', '-'):
##        if len(args) == 0:
##            raise TypeError(operator + 'requires at least 1 argument')
        if len(args) == 1:
            return -args[0]
        return sum(args[:1] + [-arg for arg in args[1:]])
    if operator in ('mul', '*'):
        return reduce(mul, args, 1)
    if operator in ('div', '/'):
        if len(args) != 2:
            raise TypeError(operator + ' requires exactly 2 arguments')
        numer, denom = args
        return float(numer)/denom

def calc_parse(line):
    tokens = tokenize(line)
    ### distinguish between assignment and expression ###
    if len(tokens)>2 and tokens[1] == '=':
        #ג'#
        if tokens[0] in known_operators:
            raise SyntaxError('variable cannot get name of an operator: ' + tokens[0])
        if not tokens[0].isalpha():
            raise SyntaxError('variable name cannot contain non-alphabetical symbols: ' + tokens[0])
        else:
            execute(tokens)
        ######
    else:
    #####################################################
        expression_tree = analyze(tokens)
        if len(tokens) > 0:
            raise SyntaxError('Extra token(s): ' + ' '.join(tokens))
        return expression_tree

### add token '=' ###
def tokenize(line):
    ### .replace('=',' = ') ###
    spaced = line.replace('(',' ( ').replace(')',' ) ').replace(',', ' , ').replace('=',' = ')
    ###
    #OR
    # spaced = line.replace('=',' = ')
    ###
    return spaced.strip().split()

known_operators = ['add', 'sub', 'mul', 'div', '+', '-', '*', '/']

###### execute assignment x = expression ######
def execute(tokens):
    var = tokens.pop(0)
    tokens.pop(0) # remove '='
    expression_tree = analyze(tokens)
    if len(tokens) > 0:
        raise SyntaxError('Extra token(s): ' + ' '.join(tokens))
    env[var]=calc_eval(expression_tree)
###############################################
    
def analyze(tokens):
    assert_non_empty(tokens)
    token = analyze_token(tokens.pop(0))
    if type(token) in (int, float):
        return token
    if token in known_operators:
        if len(tokens) == 0 or tokens.pop(0) != '(':
            raise SyntaxError('expected ( after ' + token)
        return Exp(token, analyze_operands(tokens))
    else:
        return token
        
def analyze_operands(tokens):
    assert_non_empty(tokens)
    operands = []
    while tokens[0] != ')':
        if operands and tokens.pop(0) != ',':
            raise SyntaxError('expected ,')
        operands.append(analyze(tokens))
        assert_non_empty(tokens)
    tokens.pop(0)  # Remove )
    return operands

def assert_non_empty(tokens):
    if len(tokens) == 0:
        raise SyntaxError('unexpected end of line')

def analyze_token(token):
    try:
        return int(token)
    except (TypeError, ValueError):
        try:
            return float(token)
        except (TypeError, ValueError):
            return token

##bet
##calc> add()
##TypeError: all operators require at least 1 argument
##calc> n=3
##calc> add(n,2)
##5
##calc> add = 5
##SyntaxError: variable cannot get name of an operator: add
##calc> ad2 = 5
##SyntaxError: variable name cannot contain non-alphabetical symbols: ad2
##calc> nnn = 10
##calc> nnn
##10
##calc> m
##NameError: unbound variable m
##calc> 


