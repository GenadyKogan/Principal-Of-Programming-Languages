#Q1
#alef
def foo():  #3
	def d(x):  #3
		return x*2
	return d
	
f = foo()  #3
f(100)  #3
#test:
print(f(100))

#bet
def foo(y):
    return x+y
def goo(x):
    return foo(5)
x = 10
#print(goo(50))

    
#Q2
class Rlist(object):
    """A recursive list consisting of a first element and the rest."""
    def __init__(self, first, rest=None):
        self.first = first
        self.rest = rest
    def __repr__(self):
        args = repr(self.first)
        if self.rest:
            args += ', {0}'.format(repr(self.rest))
        return 'Rlist({0})'.format(args)
    def __mul__(self, num):
        return multiply(self, num)

def extend(s1, s2):
    if s1==None: return s2
    return Rlist(s1.first, extend(s1.rest, s2))
                 
def multiply(lst, n):
    if n==1: return lst
    return extend(lst, multiply(lst, n-1))

#Q4
### [Appendix: Shmython]
def make_class(attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)
        return obj

    cls = { 'get': get, 'set': set, 'new': new }
    return cls
### [End of Shmython]

###class Rlist in Python
class Rlist(object):
    class EmptyList(object):
        def __len__(self):
            return 0
        #gimel
        def tolist(s):
            return []
    empty = EmptyList()
    def __init__(self, first, rest=empty):
        self.first = first
        self.rest = rest
    def __repr__(self):
        args = repr(self.first)
        if self.rest is not Rlist.empty:
            args += ', {0}'.format(repr(self.rest))
        return 'Rlist({0})'.format(args)
    def __len__(self):
        return 1 + len(self.rest)
    def __getitem__(self, i):
        if i == 0:
            return self.first
        return self.rest[i-1]
    def tolist(s):
        if s == Rlist.empty: return []
        #if s.rest == Rlist.empty: return [s.first,] #not the best solution
        return [s.first,] + s.rest.tolist()
    
###manipulation in Python
l = Rlist(1, Rlist(2))
print(repr(l))
print(len(l))
print(l[0])
print(l.tolist())

###solution
def make_rlist_class():
    def make_empty_rlist_class():
        def _len_(s):
            return 0
        def _tolist_(s):
            return []
        return make_class({'__len__':_len_, '__tolist__':_tolist_})
    empty = make_empty_rlist_class()['new']()
    def init(s,f,r=empty):
        s['set']('first',f)
        s['set']('rest',r)
    def __repr__(s):
        args = repr(s['get']('first'))
        if s['get']('rest') is not empty:
            args += ', {0}'.format(s['get']('rest')['get']('__repr__')())
        return 'Rlist({0})'.format(args)
    def __len__(s):
        return 1 + s['get']('rest')['get']('__len__')()
    def __getitem__(s, i):
        if i == 0:
            return s['get']('first')
        return s['get']('rest')['get']('__getitem__')(i-1)
    def tolist(s):
        if s == empty: return []
        return [s['get']('first'),] + s['get']('rest')['get']('__tolist__')()
    return make_class({'__init__':init,'__repr__':__repr__, '__len__':__len__,'__getitem__':__getitem__,'empty':empty, '__tolist__':tolist})
Rlist = make_rlist_class()

l = Rlist['new'](1,Rlist['new'](2))
print(l['get']('__repr__')())
print(l['get']('__len__')())
print(l['get']('__getitem__')(0))
print(l['get']('__tolist__')())




