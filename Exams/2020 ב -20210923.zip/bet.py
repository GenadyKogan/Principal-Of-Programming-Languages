import functools
import math
import operator

#Q2
class Rlist(object):
    """A recursive list consisting of a first element and the rest."""
    class Empty():
        def __next__(s):
            raise StopIteration
        def __len__(s):
            return 0
    empty = Empty()
    def __init__(self, first, rest=empty):
        self.first = first
        self.rest = rest
    def __repr__(self):
        args = repr(self.first)
        if self.rest!=empty:
            args += ', {0}'.format(repr(self.rest))
        return 'Rlist({0})'.format(args)
    #alef
    def __iter__(self):
        return RIterator(self)
    #dalet
    def __len__(self):
        return 1 + len(self.rest)
    
class RIterator():
    def __init__(self, lst):
        self.curr = lst
    #bet
    def __next__(self):
        if self.curr!=Rlist.empty:
            curr = self.curr.first
            self.curr = self.curr.rest
            return curr
        else:
            raise StopIteration  
#run example        
##l = Rlist(1, Rlist(2, Rlist(3)))
##
##it = iter(l)
##print(next(it))
##try:
##    while True:
##        print(next(it))
##except StopIteration as e:
##    print("end of iteration")
##    
##for i in l:
##    print(i)
##
##ll = list(l)
##print(ll)
##
##lll = tuple(map(lambda x:x*2, l))
##print(lll)
##
##print(len(l))

#Q1
def all_tf(corpus):
    all_words = tuple(functools.reduce(operator.add, [d.split() for d in corpus]))
    return tuple(map(lambda d: dict((y, round(d.split().count(y)/len(d.split()),3)) for y in all_words), corpus))
print(all_tf(("my cat is fat fat", "my dog is fat and crazy")))

def idf(w, docs):
    return round(math.log(len(docs)/len(tuple(filter(lambda x: w in x, docs))),10),3)
print(idf("cat", (("my", "cat", "fat",  "fat"), ("my", "dog", "fat", "crazy"))))

def all_idf(corpus):
    docs = tuple(d.split() for d in corpus)
    return dict(set(map(lambda x: (x, idf(x,docs)), functools.reduce(lambda x,y:x+y,docs))))
print(all_idf(("my cat is fat fat", "my dog is fat and crazy")))

def all_tf_idf(corpus):
    tf = all_tf(corpus)
    idf = all_idf(corpus)
    return tuple(dict((x,round(d[x]*idf[x],3)) for x in idf.keys()) for d in tf)
print(all_tf_idf(("my cat is fat fat", "my dog is fat and crazy")))

def search(query,corpus):
    vectors = all_tf_idf(corpus)
    scores = tuple(sum((v[x] for x in v.keys() if x in query.split())) for v in vectors)
    return corpus[scores.index(functools.reduce(max,scores))]
print(search("fat cat", ("my cat is fat fat", "my dog is fat and crazy")))


#Q4:
### [Appendix: Shmython]
def make_class(attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value):
            attrs[name] = value
    def new(*args):
        inst = make_instance(cls)
        init  = cls['get']('__init__')
        if init: init(inst, *args)
        return inst
    cls = { 'get': get, 'set': set, 'new': new }
    return cls
def make_instance(cls):
        attrs = {}
        def get(name):
            if name in attrs:
                return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value):
                    return lambda *args: value(obj, *args)
                else:
                    return value
        def set(name, value):
            attrs[name] = value
        obj   = { 'get': get, 'set': set }
        return obj
### [End of Shmython]

###solution:
#alef - cancel default value to 'base'
def make_class(attrs, base):
    #
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value):
        #hey - raise exception if name is longer than 20 chars or has non-alphabetic characters
            if len(name)>20: raise SyntaxError("attribute name "+name+" exceeds max length of 20 characters")
            #if not name.isalpha(): raise SyntaxError("attribute name "+name+" contains invalid characters")
            attrs[name] = value
    def new(*args):
        inst = make_instance(cls)
        #alef - simplify initialization
        #init  = cls['get']('__init__')
        #if init: init(inst, *args)
        get('__init__')(inst,*args)
        return inst
    cls = { 'get': get, 'set': set, 'new': new }
    return cls
def make_instance(cls):
        attrs = {}
        def get(name):
            if name in attrs:
                return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value):
                    return lambda *args: value(obj, *args)
                else:
                    return value
        def set(name, value):
            #hey - raise exception if name is longer than 20 chars or has non-alphabetic characters
            if len(name)>20: raise SyntaxError("attribute name "+name+" exceeds max length of 20 characters")
            #if not name.isalpha(): raise SyntaxError("attribute name "+name+" contains invalid characters")
            attrs[name] = value
        obj   = { 'get': get, 'set': set }
        #bet - add '__dict__' attribute to attrs
        obj['set']('__dict__',attrs) #OR set('__dict__',attrs) OR attrs['__dict__'] = attrs
        #
        #gimel - add '__type__' attribute to attrs
        obj['set']('__type__',cls) #OR set('__type__',cls)
        return obj

#alef - make top object with empty '__init__'
def make_object_class():
    def __init__(self,*args):
        pass
    #dalet - define clone function as a class attribute of TOP_OBJECT
    def __clone__(self):
        cln = make_instance(self['get']('__type__'))
        for k,v in self['get']('__dict__').items():
            cln['set'](k,v)
        return cln
    return make_class(locals(), None)
top_object = make_object_class()

#run example:
##def make_account_class():
##    return make_class({ },top_object)
##
##Account = make_account_class()
##Jim = Account['new']('Jim')
##print(Jim['get']('__dict__'))
### {'__dict__': {...}}
##Jim2 = Jim['get']('__clone__')()
##print(Jim2['get']('owner'))
### None
##print(Jim2['get']('balance'))
### None
##Jim2['set']('balance',100)
##print(Jim2['get']('balance'))
### 100
##print(Jim['get']('balance'))
### None 

#run example:
##def make_account_class():
##    def __init__(self, owner):
##        self['set']('owner', owner)
##        self['set']('balance',0)
##    return make_class({ '__init__' : __init__ }, top_object)
##
##Account = make_account_class()
##Jim = Account['new']('Jim')
##print(Jim['get']('__dict__'))
### {'balance': 0, 'owner': 'Jim', '__dict__': {...}}
##Jim2 = Jim['get']('__clone__')()
##print(Jim2['get']('owner'))
### Jim
##print(Jim2['get']('balance'))
### 0
##Jim2['set']('balance',100)
##print(Jim2['get']('balance'))
### 100
##print(Jim['get']('balance'))
### 0
##John = Jim['get']('__type__')['new']('John')
##print(John['get']('owner'))
###Account['set']('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',0)
