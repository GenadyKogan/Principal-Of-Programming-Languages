#solution, moed aleph 2016

#Q1
class Tree():
    def __init__(self, left, right):
        self.left = left
        self.right = right

##    def __repr__(self): 
##        return 'Tree({0},{1})'.format(repr(self.left), repr(self.right))
        
    def __str__(self):
        return "tree"

    def __repr__(self): 
        return 'Tree({0},{1})'.format(self.left, self.right)

def mirror(tree):
    left = tree.left if type(tree.left) != Tree else mirror(tree.left)
    right = tree.right if type(tree.right) != Tree else mirror(tree.right)
    return Tree(right, left)
#OR
##def mirror(tree):
##    if type(tree) != Tree:
##        return tree
##    return Tree(mirror(tree.right), mirror(tree.left))


tree = Tree(Tree(5,6), Tree(1, Tree(2,3)))
print(tree)
print(repr(tree))
print(mirror(tree))

### --- Q2 ---

def compose (f,g):
    return lambda x: f(g(x))

def incr(x):
    return x+1
def square(x):
    return x*x

comp = compose(incr, square)
print(comp(3))

def repeated(f, t):
    r = f
    for _ in range(1,t):
        f = compose(f,r)
    return f

print(repeated(incr, 4) (2))
print(repeated (square, 2)(5))

#Q3
def dynamic_path(x, y):
    start = (x, y)
    curr = (x, y)
    passed = [start]
    dist = 0
    def move(dX, dY):
        nonlocal dist
        dist = dist + abs(dX) + abs(dY)
        nonlocal curr
        curr = (curr[0]+dX, curr[1]+dY)
        passed.append(curr)
    def show():
        print('start: '+str(start))
        print('current position: '+str(curr))
        print('distance: '+str(dist))
    def simulate():
        i = 0
        def notEnd():
          return i < len(passed)
        def nextStop():
            nonlocal i
            if notEnd():
                res = passed[i]
                i+=1
                return res
            return "you missed the last stop"
        def dispatch(msg):
            if msg == 'notEnd':
                return notEnd
            if msg == 'nextStop':
                return nextStop
            else:
                return 'Unknown operation'
        return dispatch
    def dispatch(msg):
        if msg == 'move':
            return move
        if msg == 'show':
            return show
        if msg == 'simulate':
            return simulate
        else:
            return 'Unknown operation'
    return dispatch

path = dynamic_path(1,2)
path('move')(1, 1)
path('show')()
##start: (1, 2)
##current position: (2, 3)
##distance: 2
path('move')(2,3)
path('move')(-2,-3)
path('show')()
##start: (1, 2)
##current position: (2, 3)
##distance: 12
simulator = path('simulate')()
while simulator('notEnd')():
    print(simulator('nextStop')())
##(1, 2)
##(2, 3)
##(4, 6)
##(2, 3)
print(simulator('nextStop')())
##you missed the last stop
for _ in range(1,3):
    path('move')(1,1)
    path('show')()
##start: (1, 2)
##current position: (3, 4)
##distance: 14
##start: (1, 2)
##current position: (4, 5)
##distance: 16

#Q5

### [Appendix: Shmython]
def make_class(name, attrs, base=None):
    def make_instance(cls):
        attrs = {}
        def get(name):
            if name in attrs:
                return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value):
                    return lambda *args: value(obj, *args)
                else:
                    return value
        def set(name, value):
            attrs[name] = value
        obj   = { 'get': get, 'set': set }
        return obj
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value
    def new(*args):
        inst = make_instance(cls)
        init  = cls['get']('__init__')
        if init: init(inst, *args)
        return inst
    cls = { 'get': get, 'set': set, 'new': new }
    return cls
### [End of Shmython]

### solution:
### a) add __dict__ ; b) add __class__ ; c) add __clone__ for object

def make_class(name, attrs, base=None):
    def make_instance(cls):
        attrs = {}
        def get(name):
            if name in attrs:
                return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value):
                    return lambda *args: value(obj, *args)
                else:
                    return value
        def set(name, value):
            attrs[name] = value

        obj   = { 'get': get, 'set': set }
        
        # aleph
        obj['set']('__dict__', attrs)

        # bet
        obj['set']('__class__', cls)
        
        return obj
    
    # gimel
    # return copy of obj
    def clone(obj):
        cl = make_instance(obj['get']('__class__'))
        #OR
        #cl = make_instance(cls)
        for key, val in obj['get']('__dict__').items():
            cl['set'](key,val)
        return cl

    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def set(name, value): attrs[name] = value

    def new(*args):
        inst = make_instance(cls)
        init  = cls['get']('__init__')
        if init: init(inst, *args)
        return inst

    cls = { 'get': get, 'set': set, 'new': new }

    # gimel 
    cls['set']('__clone__', clone)
    #Also was possible to add it to object itself but without parameter obj (as function and not method)

    return cls

def make_account_class():
    def __init__(self, owner):
        self['set']('owner', owner)
        self['set']('balance',0)
    return make_class('Account', { '__init__' : __init__ }, None)

def make_save_account_class():
   return make_class('SaveAccount', { }, Account) 

Account = make_account_class()
Jim = Account['new']('Jim')
print(Jim['get']('__dict__'))
# {'balance': 0, 'owner': 'Jim', '__class__': {'get': ..., 'new': ..., 'set': ...}, '__dict__': {...}}
Jim2 = Jim['get']('__clone__')()
print(Jim2['get']('owner'))
# Jim
print(Jim2['get']('balance'))
# 0
Jim2['set']('balance',100)
print(Jim2['get']('balance'))
# 100
print(Jim['get']('balance'))
# 0


