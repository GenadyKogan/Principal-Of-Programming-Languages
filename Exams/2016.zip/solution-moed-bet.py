# Q1: RECURSION & RECURSIVE DS (10 points)

def sum_filter_tree(tree, f):
    if type(tree)!=tuple:
        if f(tree):
            return tree
        else:
            return 0
    return sum(sum_filter_tree(branch, f) for branch in tree)


# 6

# Q2: pipeline

def get_excellent_students(threshold, data):
##    return tuple(map(lambda x: x[0], filter(lambda y: y[1]>threshold,
##                                            map(lambda x: (x[0],
##                                                           sum(filter(lambda y: type(y)==int, x))/len(tuple(filter(lambda y: type(y)==int, x)))), data))))
    #OR
    return tuple(map(lambda x: x[0], filter(lambda y: y[1]>threshold, map(lambda x: (x[0], sum(x[1:])/len(tuple(x[1:]))), data))))
    

data = (('Moshe', 45, 67, 80, 30), ('Shlomo', 90, 85, 95, 87), ('Rinat', 67, 70, 80, 75), ('Mai', 90, 95, 95, 93))
print(get_excellent_students(85, data))
# ('Shlomo', 'Mai')

# Q3: generic functions

# Rlist:
class Rlist(object):
    """A recursive list consisting of a first element and the rest."""
    class EmptyList(object):
            def __len__(self):
                return 0
    empty = EmptyList()
    def __init__(self, first, rest=empty):
            self.first = first
            self.rest = rest
    def __repr__(self):
        args = repr(self.first)
        if self.rest is not Rlist.empty:
            args += ', {0}'.format(repr(self.rest))
        return 'Rlist({0})'.format(args)
    def __len__(self):
            return 1 + len(self.rest)
    def __getitem__(self, i):
            if i == 0:
                return self.first
            return self.rest[i-1]
###########
#--------------solution---------------------

def type_tag(x):     return type_tag.tags[type(x)]

type_tag.tags = {int: 'int', list: 'lst', Rlist: 'rst'}

def add_rst_list(rst, lst):
    res = lst
    for i in range(len(rst)):
        res = res+[rst[i]]
    return res
    
def add_rsts(r1, r2):
    if len(r1) == 0:
        return r2
    return Rlist(r1[0],add_rsts(r1.rest,r2))
                 
def mul_rst_int(rst, k):
    tmp = rst
    for _ in range(k-1):
        rst = add_rsts(rst,tmp)
    return rst

def apply(operator_name, x, y):
    tags = (type_tag(x), type_tag(y))
    key = (operator_name, tags)
    return apply.implementations[key](x, y)


apply.implementations = { ('add', ('int', 'int')): lambda x, y: x+y,
                          ('add', ('lst', 'lst')): lambda x, y: x+y,
                          ('add', ('rst','rst')): add_rsts,
                          ('add', ('rst','lst')): add_rst_list,
                          ('add', ('lst','rst')): lambda x ,y: add_rst_list(y,x),
                          ('mul', ('int', 'int')): lambda x, y: x*y,
                          ('mul', ('lst', 'int')): lambda x, y: x*y,
                          ('mul', ('int', 'lst')): lambda x, y: x*y,
                          ('mul', ('rst','int')): mul_rst_int,
                          ('mul', ('int','rst')): lambda x ,y: mul_rst_int(y,x)
                          }

print(apply('add', [1,2,3], Rlist(4, Rlist(5, Rlist(6)))))
# [1, 2, 3, 4, 5, 6]
print(apply('add', Rlist(1, Rlist(2, Rlist(3))), Rlist(4, Rlist(5, Rlist(6)))))
# Rlist(1, Rlist(2, Rlist(3, Rlist(4, Rlist(5, Rlist(6))))))
print(apply('mul', Rlist(4, Rlist(5, Rlist(6))), 2))
# Rlist(4, Rlist(5, Rlist(6, Rlist(4, Rlist(5, Rlist(6))))))
print(apply('mul', 2, Rlist(4, Rlist(5, Rlist(6)))))
# Rlist(4, Rlist(5, Rlist(6, Rlist(4, Rlist(5, Rlist(6))))))

# Q5: Shmython: add multiple inheritance and super (30 points)

### [Appendix: Shmython]
def make_class(attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)
        return obj

    cls = { 'get': get, 'set': set, 'new': new }
    return cls
### [End of Shmython]

### solution

def make_class(attrs, base = None):
    
    # dalet super
    def super(ob, *args):
        if base:
            init  = base['get']('__init__')
            if init: init(ob, *args)
    
    def get(name):
        if name in attrs: return attrs[name]
        elif base:
            return base['get'](name)
                
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)

        return obj

    cls = { 'get': get, 'set': set, 'new': new }

    # Q5 dalet set super
    cls['set']('super', super)

    return cls

def make_account_class():
    def __init__(self, owner):
        self['set']('bank','shmapolim')
        self['set']('owner', owner)
        self['set']('balance',0)
    return make_class({ '__init__' : __init__ }, None)
        
def make_save_account_class():
    def __init__(self, owner, balance):
        self['get']('super')(owner)
        self['set']('balance', balance)
    return make_class({'__init__' : __init__ }, Account) 

Account = make_account_class()
Jim = Account['new']('Jim')
print(Jim['get']('bank'))
# shmapolim
print(Jim['get']('balance'))
# 0
print(Jim['get']('owner'))
# Jim
SaveAccount = make_save_account_class()
Jack = SaveAccount['new']('Jack',200)
print(Jack['get']('bank'))
# shmapolim
print(Jack['get']('balance'))
# 200
print(Jack['get']('owner'))
# Jack
