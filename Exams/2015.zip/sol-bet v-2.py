### --- Q1 ---
from operator import add, mul
from functools import reduce

def accumulate_tree(f, tree):
    if type(tree) != tuple:
        return tree
    return reduce(f, [accumulate_tree (f, branch) for branch in tree])

#print(accumulate_tree(add, ((2, 3), (4, (5, 6, (8, 2))))))
# 30

#print(accumulate_tree(mul, ((2, 3), (4, (5, 6, (8, 2))))))
# 11520

class Tree():
    def __init__(self, value, nodes=None):
        self.value = value
        self.nodes = nodes

    def __repr__(self): 
        if self.nodes: return 'Tree({0},{1})'.format(self.value,repr(self.nodes))
        return 'Tree({0})'.format(self.value)

def transform(f, tree):
    if type(tree) != tuple:
        return Tree(tree)
    nodes = [transform(f, branch) for branch in tree]
    return Tree(reduce(f, [n.value for n in nodes]), nodes)

#print(transform(add, (((2, 3), (4, (5, 6, (8, 2)))))))
# Tree(5,30,[Tree(2,5,[Tree(1,2), Tree(1,3)]), Tree(4,25,[Tree(1,4), Tree(3,21,[Tree(1,5), Tree(1,6), Tree(2,10,[Tree(1,8), Tree(1,2)])])])])
#print(transform(add, ((2, 3), (4, (5, 6)))))
# Tree(20,[Tree(5,[Tree(2), Tree(3)]), Tree(15,[Tree(4), Tree(11,[Tree(5), Tree(6)])])])

### --- Q5 ---

### [Appendix: Shmython]
def make_class(attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)
        return obj

    cls = { 'get': get, 'set': set, 'new': new }
    return cls
### [End of Shmython]

### solution

def make_class(name, attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    # Q5e define mro as a class attribute
    def mro(ob):
        if not base: return [attrs['name']]
        res = base['get']('mro')(ob)
        res.insert(0, attrs['name'])
        return res

    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)

        # Q5b   set type
        obj['set']('type', cls['get']('name'))

        # Q5c set this
        obj['set']('this', cls)

        # Q5d set super
        obj['set']('super', base)

        return obj

    cls = { 'get': get, 'set': set, 'new': new }

    # Q5a   set class name
    #       or: set('name', name)
    #       or: attrs['name'] = name
    cls['set']('name', name)

    # Q5e set mro
    cls['set']('mro', mro)

    return cls

def make_account_class():
    def __init__(self, owner):
        self['set']('owner', owner)
    return make_class('Account', { '__init__' : __init__ }, None)

def make_save_account_class():
   return make_class('SaveAccount', { }, Account) 

Account = make_account_class()
print(Account['get']('name'))
# Account
Jim = Account['new']('Jim')
print(Jim['get']('type'))
# 'Account'
Bob = Jim['get']('this')['new']('Bob')
print(Bob['get']('type'))
# Account
SaveAccount = make_save_account_class()
Jack = SaveAccount['new']('Jack')
print(Jack['get']('type'))
# SaveAccount
John = Jack['get']('this')['new']('John')
print(John['get']('type'))
# SaveAccount
Liz = Jack['get']('super')['new']('Liz')
print(Liz['get']('type'))
# Account
print(John['get']('mro')())
# ['SaveAccount', 'Account']




