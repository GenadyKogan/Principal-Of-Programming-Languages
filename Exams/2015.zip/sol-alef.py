from functools import reduce
from operator import add

#--- q1 (tail recusrsion) ---
def map_extend(f, lst, ext):
        if len(ext)==0:
                return lst
        return map_extend(f, lst+[f(ext[0])], ext[1:])

# other (less efficient) solutions have been accepted

#print(map_extend(lambda x: x*x, [1,2,3,4], [1,2,3,4]))
# [1, 2, 3, 4, 1, 4, 9, 16]

# --- q2 ---
def cartezian_product(l1, l2):
        return reduce(add, tuple(map(lambda x: tuple(map(lambda y: (x,y), l2)), l1)))

#make_pairs = lambda el, lst: tuple(map(lambda x: (el, x), lst))
#--alternative----#
make_pairs = lambda el, lst: tuple((el, x) for x in lst)

#c_prod = lambda lst1, lst2: tuple(map(lambda x: make_pairs(x, lst2), lst1))
#--alternative----#
c_prod = lambda lst1, lst2: tuple(make_pairs(x, lst2)for x in lst1)

#flat_c_prod = lambda lst1, lst2: reduce(add, c_prod(lst1, lst2), ())
#--alternative----#
flat_c_prod = lambda lst1, lst2: reduce(lambda x,y:x+y, c_prod(lst1, lst2), ())

#cond_c_prod = lambda p, lst1, lst2: flat_c_prod(tuple(filter(p, lst1)), tuple(filter(p, lst2)))
#--alternative----#
cond_c_prod = lambda p, lst1, lst2: tuple(filter(lambda x: p(x[0]) and p(x[1]), flat_c_prod(lst1, lst2)))
                                           
print(make_pairs(2, (1,2,3)))
##((2, 1), (2, 2), (2, 3))

print(c_prod((1, 2), (3, 4)))
##(((1, 3), (1, 4)), ((2, 3), (2, 4)))

print(flat_c_prod((1, 2), (3, 4)))
#((1, 3), (1, 4), (2, 3), (2, 4))

print(cond_c_prod(lambda x: type(x)== int,(1, 2, 3.5), (3, 'a', 4)))
#((1, 3), (1, 4), (2, 3), (2, 4))


# Q3: MESSAGE PASSING & EXCEPTIONS (25 points)
def get_filter_iterator(lst, p=lambda x: True):
    ind = 0
    def next():
        nonlocal ind
        if ind >= len(lst):
            return "no more items"
        try:
            item = lst[ind]
            ind+=1
            if p(item):
                return item
            else:
                return next()
        except(ArithmeticError, ValueError, TypeError) as err:
            ind+=1
            return next()
    def has_more():
        tmp = ind
        while tmp < len(lst):
            try:
                if p(lst[tmp]): return True
                tmp+=1
            except(ArithmeticError, ValueError, TypeError):
                tmp+=1
        return False
        #return ind < len(lst)
    return {'next':next, 'has_more':has_more}

it = get_filter_iterator((1,0,6), lambda x: x%2==0)
while it['has_more']():
    print(it['next']())

##0
##6

##it = get_filter_iterator((1,0,6,2), lambda x: 5/x > 1)
##while it['has_more']():
##    print(it['next']())

##1
##2

##it = get_filter_iterator((1,0,6))
##for _ in range(1,6):
##    print(it['next']())

##1
##0
##6
##no more items
##no more items

#Q3: ------Alternative solution---------

def get_filter_iterator(lst, p=lambda x: True):
    ind = 0
    def next():
        nonlocal ind
        try:
            item = lst[ind]
            ind+=1
            if p(item):
                return item
            else:
                return next()
        except(IndexError):
            return "no more items"
        except(ArithmeticError, ValueError, TypeError) as err:
            ind+=1
            return next()
    def has_more():
        tmp = ind
        while True:
            try:
                if p(lst[tmp]): return True
                tmp+=1
            except(IndexError):
                    return False
            except(ArithmeticError, ValueError, TypeError):
                tmp+=1
        return False
        #return ind < len(lst)
    return {'next':next, 'has_more':has_more}

##it = get_filter_iterator((1,0,6), lambda x: x%2==0)
##while it['has_more']():
##    print(it['next']())
##0
##6

##it = get_filter_iterator((1,0,6,2), lambda x: 5/x > 1)
##while it['has_more']():
##    print(it['next']())
##1
##2

##it = get_filter_iterator((1,0,6))
##for _ in range(1,6):
##    print(it['next']())
##1
##0
##6
##no more items
##no more items


#Q5: Interpreter
##---Solution 1 (long for b.)---##
from functools import reduce
from operator import mul,add
from math import sqrt

##def repl():
##    
##    while True:
##        try:
##            expression_tree = calc_parse(input('calc> '))                    
##            print(calc_eval(expression_tree))
##        #### new errors: ValueError, ArithmeticError ####
##        except (SyntaxError, TypeError, ValueError, ArithmeticError) as err:
##            print(type(err).__name__ + ':', err)
##        except (KeyboardInterrupt, EOFError):  # <Control>-D, etc. <ctrl-C>
##            print('Calculation completed.')
##            return
##
### Eval & Apply
##
##class Exp(object):
##    def __init__(self, operator, operands):
##        self.operator = operator
##        self.operands = operands
##
##    def __repr__(self):
##        return 'Exp({0}, {1})'.format(repr(self.operator), repr(self.operands))
##
##    def __str__(self):
##        operand_strs = ', '.join(map(str, self.operands))
##        return '{0}({1})'.format(self.operator, operand_strs)
##
##def calc_eval(exp):
##    if type(exp) in (int, float):
##        return exp
##    if type(exp) == Exp:
##        arguments = list(map(calc_eval, exp.operands))
##        return calc_apply(exp.operator, arguments)
##    ##### sequence ###
##    if type(exp) == list:
##          return list(map(calc_eval, exp))
##    
##def calc_apply(operator, args):
##    if operator in ('add', '+'):
##        return sum(args)
##    if operator in ('sub', '-'):
##        if len(args) == 0:
##            raise TypeError(operator + 'requires at least 1 argument')
##        if len(args) == 1:
##            return -args[0]
##        return sum(args[:1] + [-arg for arg in args[1:]])
##    if operator in ('mul', '*'):
##        #new test
##        if len(args) == 0:
##            raise TypeError(operator + 'requires at least 1 argument')
##        return reduce(mul, args, 1)
##    if operator in ('div', '/'):
##        if len(args) != 2:
##            raise TypeError(operator + ' requires exactly 2 arguments')
##        #numer, denom = args
##        #returns infinite if denominator = 0
####        if denom == 0: return float("inf")
####        return float(numer)/denom
##        #OR:
##        try:
##                return args[0]/args[1]
##        except(ZeroDivizionError):
##                return float("inf")
##    #### new operator - round ####
##    if operator == 'round':
##        if len(args) != 2:
##            raise TypeError(operator + ' requires exactly 2 arguments')
##        base, prec = args
##        return round(base, prec)
##    
### Parsing
##
##def calc_parse(line):
##    tokens = tokenize(line)
##    #### sequence of commands ####
##    if ';' in tokens:
##        result = []
##        while ';' in tokens:
##            token = tokens[0:tokens.index(';')]
##            result.append(analyze(token))
##            tokens = tokens[tokens.index(';')+1:]
##    else:
##    ##############################
##            result = analyze(tokens)
##    if len(tokens) > 0:
##        raise SyntaxError('Extra token(s): ' + ' '.join(tokens))
##    return result
##
##def tokenize(line):
##    #### add token ';' ###
##    spaced = line.replace('(',' ( ').replace(')',' ) ').replace(',', ' , ').replace(';',' ; ')
##    return spaced.strip().split()
##
###new operator: 'round'
##known_operators = ['round', 'add', 'sub', 'mul', 'div', 'pow', 'sqrt', '+', '-', '*', '/', '^', 'V']
##
##def analyze(tokens):
##    assert_non_empty(tokens)
##    token = analyze_token(tokens.pop(0))
##    if type(token) in (int, float):
##        return token
##    if token in known_operators:
##        if len(tokens) == 0 or tokens.pop(0) != '(':
##            raise SyntaxError('expected ( after ' + token)
##        return Exp(token, analyze_operands(tokens))
##    else:
##        return token
##        
##def analyze_operands(tokens):
##    assert_non_empty(tokens)
##    operands = []
##    while tokens[0] != ')':
##        if operands and tokens.pop(0) != ',':
##            raise SyntaxError('expected ,')
##        operands.append(analyze(tokens))
##        assert_non_empty(tokens)
##    tokens.pop(0)  # Remove )
##    return operands
##
##def assert_non_empty(tokens):
##    if len(tokens) == 0:
##        raise SyntaxError('unexpected end of line')
##
##def analyze_token(token):
##    try:
##        return int(token)
##    except (TypeError, ValueError):
##        try:
##            return float(token)
##        except (TypeError, ValueError):
##            return token

####OUTPUT examples#####
# calc> round(div(1,6),3); add(1,2);mul(1,2);add(3,4);
# [0.167, 3, 2, 7]

# calc> round(div(1,6),3); add(1,2);mul(1,2);add(3,4)
# SyntaxError: Extra token(s): add ( 3 , 4 )


##Q5:-----Alternative (very short for b. :)) solution------##
##NOTE a small update: last expression in a sequence must NOT end by ';' in this solution!##
##';' appears only between expressions!##
##otherwise, interpreter expects for a next expression after the last ';' that causes error##

def repl():
    
    while True:
        try:
            row = input('calc> ')
            #######check ';' in the input ######
            if ';' in row:
                    expressions = list(map(calc_parse, row.split(';')))
                    print(list(map(calc_eval, expressions)))
            else:
                    print(calc_eval(calc_parse(row)))
        #### new errors: ValueError, ArithmeticError ####
        except (SyntaxError, TypeError, ValueError, ArithmeticError) as err:
            print(type(err).__name__ + ':', err)
        except (KeyboardInterrupt, EOFError):  # <Control>-D, etc. <ctrl-C>
            print('Calculation completed.')
            return

# Eval & Apply

class Exp(object):
    def __init__(self, operator, operands):
        self.operator = operator
        self.operands = operands

    def __repr__(self):
        return 'Exp({0}, {1})'.format(repr(self.operator), repr(self.operands))

    def __str__(self):
        operand_strs = ', '.join(map(str, self.operands))
        return '{0}({1})'.format(self.operator, operand_strs)

def calc_eval(exp):
    if type(exp) in (int, float):
        return exp
    if type(exp) == Exp:
        arguments = list(map(calc_eval, exp.operands))
        return calc_apply(exp.operator, arguments)
    
def calc_apply(operator, args):
    if operator in ('add', '+'):
        return sum(args)
    if operator in ('sub', '-'):
        if len(args) == 0:
            raise TypeError(operator + 'requires at least 1 argument')
        if len(args) == 1:
            return -args[0]
        return sum(args[:1] + [-arg for arg in args[1:]])
    if operator in ('mul', '*'):
        #new test
        if len(args) == 0:
            raise TypeError(operator + 'requires at least 1 argument')
        return reduce(mul, args, 1)
    if operator in ('div', '/'):
        if len(args) != 2:
            raise TypeError(operator + ' requires exactly 2 arguments')
        try:
                return args[0]/args[1]
        except(ZeroDivizionError):
                return float("inf")
    #### new operator - round ####
    if operator == 'round':
        if len(args) != 2:
            raise TypeError(operator + ' requires exactly 2 arguments')
        base, prec = args
        return round(base, prec)
    
# Parsing

def calc_parse(line):
    tokens = tokenize(line)
    result = analyze(tokens)
    if len(tokens) > 0:
        raise SyntaxError('Extra token(s): ' + ' '.join(tokens))
    return result

def tokenize(line):
    spaced = line.replace('(',' ( ').replace(')',' ) ').replace(',', ' , ')
    return spaced.strip().split()

#new operator: 'round'
known_operators = ['round', 'add', 'sub', 'mul', 'div', 'pow', 'sqrt', '+', '-', '*', '/', '^', 'V']

def analyze(tokens):
    assert_non_empty(tokens)
    token = analyze_token(tokens.pop(0))
    if type(token) in (int, float):
        return token
    if token in known_operators:
        if len(tokens) == 0 or tokens.pop(0) != '(':
            raise SyntaxError('expected ( after ' + token)
        return Exp(token, analyze_operands(tokens))
    else:
        return token
        
def analyze_operands(tokens):
    assert_non_empty(tokens)
    operands = []
    while tokens[0] != ')':
        if operands and tokens.pop(0) != ',':
            raise SyntaxError('expected ,')
        operands.append(analyze(tokens))
        assert_non_empty(tokens)
    tokens.pop(0)  # Remove )
    return operands

def assert_non_empty(tokens):
    if len(tokens) == 0:
        raise SyntaxError('unexpected end of line')

def analyze_token(token):
    try:
        return int(token)
    except (TypeError, ValueError):
        try:
            return float(token)
        except (TypeError, ValueError):
            return token

####OUTPUT examples#####
# calc> round(div(1,6),3); add(1,2);mul(1,2);add(3,4)
# [0.167, 3, 2, 7]

# calc> round(div(1,6),3); add(1,2);mul(1,2);add(3,4);
# SyntaxError: unexpected end of line
