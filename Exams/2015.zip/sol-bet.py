from operator import add
### --- Q1 ---
def get_depth(tree):
    if type(tree) != tuple:
	    return 1
    return 1+ max(map(get_depth,tree))

# print(get_depth(((2, 3), (4, (5, 6)))))
# 4

# print(get_depth(((2, 3), (4, (5, 6, (8, 2))))))
# 5

class Tree():
    def __init__(self, depth, nodes=None):
        self.depth = depth
        self.nodes = nodes

    def __repr__(self): 
        if self.nodes: return 'Tree({0},{1})'.format(self.depth,repr(self.nodes))
        return 'Tree(1)'

def transform(tree):
    if type(tree) != tuple:
        return Tree(1)
    nodes = list(map(transform, tree))
    return Tree(1+ max(n.depth for n in nodes), nodes)

##print(transform(((2, 3), (4, (5, 6)))))
##Tree(4,[Tree(2,[Tree(1), Tree(1)]), Tree(3,[Tree(1), Tree(2,[Tree(1), Tree(1)])])])
# print(transform(((2, 3), (4, (5, 6, (8, 2))))))
# Tree(5,[Tree(2,[Tree(1), Tree(1)]), Tree(4,[Tree(1), Tree(3,[Tree(1), Tree(1), Tree(2,[Tree(1), Tree(1)])])])])

### --- Q2 ---

# 'add' (concatination) and 'intersection' between list and string, Rlist and string, and Rlist and list
# via coercion to list
class Rlist(object):
    class EmptyList(object):
        def __len__(self):
            return 0
    empty = EmptyList()
    def __init__(self, first, rest=empty):
        self.first = first
        self.rest = rest
    def __repr__(self):
        args = repr(self.first)
        if self.rest is not Rlist.empty:
            args += ', {0}'.format(repr(self.rest))
        return 'Rlist({0})'.format(args)
    def __len__(self):
        return 1 + len(self.rest)
    def __getitem__(self, i):
        if i == 0:
            return self.first
        return self.rest[i-1]
    
def type_tag(x):
    return type_tag.tags[type(x)]

type_tag.tags = {Rlist: 'rlst', list: 'lst', str: 'str'}

### ----------------- coercion -------------------

def rlist_to_list(lst):
    return [lst[i] for i in range(len(lst))]

def string_to_list(s):
    return [c for c in s]

coercions = {('rlst', 'lst'): rlist_to_list}
coercions[('str','lst')] = string_to_list

def coerce_apply(operator_name, x, y):
    tx, ty = type_tag(x), type_tag(y)
    if tx != 'lst':
        if (tx, 'lst') in coercions:
            tx, x = 'lst', coercions[(tx, 'lst')](x)
        else:
            return 'No coercion possible!'
    if ty != 'lst':
        if (ty, 'lst') in coercions:
            ty, y = 'lst', coercions[(ty, 'lst')](y)
        else:
            return 'No coercion possible!'
    key = (operator_name, tx)
    return coerce_apply.implementations[key](x, y)

coerce_apply.implementations = {('int', 'lst'): lambda x, y: list(set(x) & set(y)),
				('add', 'lst'): lambda x, y: x+y                  }

print(coerce_apply('add', Rlist(1,Rlist(2,Rlist(3))), "abcd"))
# [1, 2, 3, 'a', 'b', 'c', 'd']
print(coerce_apply('int', "234567", Rlist('1',Rlist('2',Rlist('3')))))
# ['3', '2']

### --- Q3 ---

def make_collection():
    data = []
    def put(el):
        data.append(el)
    def replace(ind, el):
        data.pop(ind);
        data.insert(ind, el)
    def accumulate(f):
        return reduce(f, data)
    def iterator():
        ind = 0
        def next():
            nonlocal ind
            try:
                item = data[ind]
                ind+=1
                return item
            except(IndexError):
                return 'End of list'    
        def restart():
            nonlocal ind
            ind = 0
        return {'next':next, 'restart':restart}
    def dispatch(msg):
        if msg == 'put':
            return put
        if msg == 'replace':
            return replace
        if msg == 'accumulate':
            return accumulate
        if msg == 'iterator':
            return iterator
        else:
            return 'Unknown operation'
    return dispatch

##coll = make_collection()
##coll('put')(1)
##coll('put')(2)
##print(coll('accumulate')(max))
### 2
##coll('replace')(1,5)
##print(coll('accumulate')(max))
### 5
##coll('put')(5)
##print(coll('accumulate')(add))
### 11
##it = coll('iterator')()
##for _ in range(1,6):
##    print(it['next']())
####1
####5
####5
####End of list
####End of list
##it['restart']()
##for _ in range(1,5):
##    print(it['next']())
####1
####5
####5
####End of list

### --- Q5 ---

### [Appendix: Shmython]
def make_class(attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)
        return obj

    cls = { 'get': get, 'set': set, 'new': new }
    return cls
### [End of Shmython]

### solution

def make_class(name, attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def instanceof(ob, name):
        if attrs['name'] == name:   return True
        if not base:    return False
        return base['get']('instanceof')(ob, name)
    
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)

        # Q5b   set type
        obj['set']('type', cls['get']('name'))

        # Q5c set this
        obj['set']('this', cls)

        return obj

    cls = { 'get': get, 'set': set, 'new': new }

    # Q5a   set class name
    #       or: set('name', name)
    #       or: attrs['name'] = name
    cls['set']('name', name)

    # Q5f set instanceof
    cls['set']('instanceof', instanceof)

    return cls

def make_account_class():
    def __init__(self, owner):
        self['set']('owner', owner)
    return make_class('Account', { '__init__' : __init__ }, None)

def make_save_account_class():
   return make_class('SaveAccount', { }, Account) 

##Account = make_account_class()
##print(Account['get']('name'))
### Account
##Jim = Account['new']('Jim')
##print(Jim['get']('type'))
### 'Account'
##Bob = Jim['get']('this')['new']('Bob')
##print(Bob['get']('type'))
### Account
##SaveAccount = make_save_account_class()
##Jack = SaveAccount['new']('Jack')
##print(Jack['get']('type'))
### SaveAccount
##John = Jack['get']('this')['new']('John')
##print(John['get']('type'))
### SaveAccount
##Liz = Jack['get']('super')['new']('Liz')
##print(Liz['get']('type'))
### Account
##print(John['get']('mro')())
### ['SaveAccount', 'Account']
##print(John['get']('instanceof')('Account'))
### True
##print(John['get']('instanceof')('SaveAccount'))
### True
##print(SaveAccount['get']('instanceof')(John, 'SaveAccount'))
### True
##print(Account['get']('instanceof')(John, 'SaveAccount'))
### False



