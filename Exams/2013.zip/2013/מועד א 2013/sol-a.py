# q1
#
# collector(('a', 2, 'd', 4, 5, 'g', 'h', 'i'), (8, 'g', 9, 'gh', 1))

def collector(s, t):
    s = filter(lambda x: not isinstance(x, int), s)
    t = filter(lambda x: not isinstance(x, int), t)
    s = map(lambda x: (1, x), s)
    t = map(lambda x: (2, x), t)
    return merge(tuple(s), tuple(t))

def merge(s, t):
    if (len(s) == 0):
        return t
    return s[:1] + merge(t, s[1:])

# q2
#
# >>> moshe = robot()
# >>> moshe['listen']('my', 'cat', 'is', 'fat')
# >>> moshe['show']()
# ['my', 'cat', 'is', 'fat']
# >>> speaker = moshe['talk']()
# >>> speaker['next']()
# 'my'
# >>> speaker['next']()
# 'cat'
# >>> speaker['next']()
# 'is'
# >>> speaker['next']()
# 'fat'
# >>> speaker['next']()
# 'my'
# >>> speaker['next']()
# 'cat'

def robot():
    mem = []

    def listen(*s):
        mem.extend(s)

    def talk():
        ns = { 'ind' : len(mem)-1 }
        def next():
            ns['ind'] = (ns['ind'] + 1) % len(mem)
            return mem[ns['ind']]
        return { 'next' : next }

    def forget():
        while (len(mem) != 0):
            mem.pop()

    def show():
        print(mem)

    return { 'listen' : listen, 'talk' : talk, 'forget' : forget, 'show' : show }


def all_sums(n, k):
    if n == 0:
        return 1
    elif n < 0:
        return 0
    else:
        res = 0
        for i in range(1, k+1):
            res = res + all_sums(n-i, k)
        return res

def memo(f):
    mem = {}
    def memoized(*args):
        if args not in mem:
            mem[args] = f(*args)
        return mem[args]
    return memoized

all_sums = memo(all_sums)

# q4
### Our custom OOP
def make_class(attrs, base=None):
    """Return a new class (a dispatch dictionary) with given class attributes"""

    # Getter: class attribute (looks in this class, then base)
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)

    # Setter: class attribute (always sets in this class)
    def set(name, value): attrs[name] = value

    # Return a new initialized object instance (a dispatch dictionary)
    def new(*args):
        # instance attributes (hides encapsulating function's attrs)
        attrs = {}

        # Getter: instance attribute (looks in object, then class (binds self if callable))
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value

        # Setter: instance attribute (always sets in object)
        def set(name, value):       attrs[name] = value

        # instance dictionary
        obj = { 'get': get, 'set': set }

        # calls constructor if present
        init = get('__init__')
        if init: init(*args)

        return obj

    # class dictionary
    cls = { 'get': get, 'set': set, 'new': new }
    return cls

def make_exam_class():
    def __init__(self, grade):
        self['set']('grade', grade)
    def final(self):
        return 'I got ' + str(attributes['grade'])
    attributes = { '__init__' : __init__, 'final' : final, 'grade' : 100 }
    return make_class(attributes, None)

Exam = make_exam_class()

#  >>> ex = Exam['new'](56)
#  >>> ex['get']('grade')
#  56
#  >>> ex['get']('final')()
#  'I got 100'
#  >>> Exam['get']('grade')
#  100
#  >>> Exam['get']('final')()
#  Traceback (most recent call last):
#    File "<stdin>", line 1, in <module>
#  TypeError: final() takes exactly 1 argument (0 given)

# Python implementation:

class Exam:
    grade = 100
    def __init__(self, grade):
        self.grade = grade
    def final(self):
        return "I got " + str(Exam.grade)

# manipulation:
##>>> ex = Exam(56)
##>>> ex.grade
##56
##>>> ex.final()
##'I got 100'
##>>> Exam.grade
##100
##>>> Exam.final()
##Traceback (most recent call last):
##  File "<pyshell#6>", line 1, in <module>
##    Exam.final()
##TypeError: final() missing 1 required positional argument: 'self'



