### [Appendix: Shmython]
def make_class(attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)
        return obj

    cls = { 'get': get, 'set': set, 'new': new }
    return cls
### [End of Shmython]


from math     import sqrt
from operator import add
from functools import reduce

# --- q1 ---
def average_passed_grade(grades):
    s = filter(lambda g: g >= 56,
               map(lambda g: 10*sqrt(g),
                   filter(lambda g: g != 199,
                          grades)))
    t = tuple(s)
    return sum (t) / len(t)

# >>> average_passed_grade([23, 64, 199, 20, 77, 98, 100, 199])
# 91.686148310009472


def average_passed_grade2(grades, f):
    s = filter(lambda g: g >= 56,
               map(lambda g: min(f(g), 100),
                   filter(lambda g: g != 199,
                          grades)))
    t = tuple(s)
    #return sum (t) / len(t) OR
    return reduce(add, t, 0) / len(t)

print(average_passed_grade2([23, 64, 199, 20, 77, 98, 100, 199], lambda x: x+15))
# 92.75


# --- q2 ---
def easy_park(fee):
    ns = { 'balance' : 0 }
    def charge(amount):
        ns['balance'] += amount
    def park(time):
        ns['balance'] -= float(time) * fee
        print('balance left: ' + str(ns['balance']))
    def dispatch(m, *args):
        if m == 'charge':
            return charge(*args)
        elif m == 'park':
            return park(*args)
        else:
            print('unknown message: ' + m)
    return dispatch

# >>> k = easy_park(5)
# >>> k('charge', 100)
# >>> k('park', 10)
# balance left: 50.0
# >>> k('add', 20)
# unknown message: add


# --- q4 ---

def common(l1, l2):
    if l1 == l2:
        return l1
    else:
        return common(l1[1:], l2[:len(l2)-1])

# >>> common(['w', 'o', 'r', 'l', 'd'], ['w', 'o', 'r', 'l', 'd'])
# ['w', 'o', 'r', 'l', 'd']
# >>> common(['p', 'y', 't', 'h', 'o', 'n'], ['o', 'n', 'l', 'i', 'n', 'e'])
# ['o', 'n']
# >>> common(['c', 'a', 't'], ['d', 'o', 'g'])
# []


# --- q5 ---

# (q5a) add class name parameter
def make_class(name, attrs, base=None):
    def get(name):
        if name in attrs: return attrs[name]
        elif base:        return base['get'](name)
    def set(name, value): attrs[name] = value

    def new(*args):
        def get(name):
            if name in attrs:       return attrs[name]
            else:
                value = cls['get'](name)
                if callable(value): return lambda *args: value(obj, *args)
                else:               return value
        def set(name, value):       attrs[name] = value

        attrs = {}
        obj   = { 'get': get, 'set': set }
        init  = get('__init__')
        if init: init(*args)

        # (q5b) update object count
        cls['set']('count', cls['get']('count')+1)

        return obj

    cls = { 'get': get, 'set': set, 'new': new }

    # (q5a) set class name
    #       or: set('name', name)
    #       or: attrs['name'] = name
    cls['set']('name', name)

    # (q5b) set object count
    #       or: set('count', 0)
    #       or  attrs['count'] = 0
    cls['set']('count', 0)

    return cls

def make_exam_class():
    def __init__(self, grade):
        self['set']('grade', grade)
    return make_class('Exam', { '__init__' : __init__ }, None)

# >>> Exam = make_exam_class()
# >>> Exam['get']('name')
# 'Exam'
# >>> Exam['get']('count')
# 0
# >>> ex = Exam['new'](80)
# >>> Exam['get']('count')
# 1
# >>> ex = Exam['new'](80)
# >>> ex = Exam['new'](85)
# >>> Exam['get']('count')
# 3
